"""rle-sdk: a small client SDK for driving Foundry RLE environments.

A Foundry RLE environment exposes the OpenEnv simulation contract
(``reset`` / ``step`` / ``state`` / ...) through the Foundry data plane. This SDK
wraps that HTTP contract behind a gym-style surface so that training jobs and
cookbook recipes can call::

    from rle_sdk import RLEEnvironment

    with RLEEnvironment(env_id="wordle-abc", project="demo") as env:
        env.reset()
        result = env.step({"message": "hello"})   # -> StepResult(observation, reward, done)
        state = env.state()

You point the client at an **environment id**; on first use it leases a fresh
sandbox from the control plane, waits for it to become ``Running``, and routes
every ``reset`` / ``step`` / ``state`` call to that sandbox's data plane. Leaving
the ``with`` block (or calling ``close()``) releases the sandbox. Instead of
invoking a local Python tool function, a recipe routes the same call to a remote,
sandboxed environment — ``env.step(...)`` is the only thing that changes.

The control plane defaults to ``$RLE_CONTROL_PLANE`` (or the deployed RLE control
plane) and the project to ``$RLE_PROJECT`` when not passed explicitly.

Both a synchronous (:class:`RLEEnvironment`) and an asyncio
(:class:`AsyncRLEEnvironment`) client are provided. The async client requires the
``aio`` extra (``pip install rle-sdk[aio]``).
"""

from ._errors import RLEError
from ._models import EnvState, StepResult
from .aio import AsyncRLEEnvironment
from .client import RLEEnvironment

__version__ = "0.1.3"

__all__ = [
    "RLEEnvironment",
    "AsyncRLEEnvironment",
    "StepResult",
    "EnvState",
    "RLEError",
    "__version__",
]
