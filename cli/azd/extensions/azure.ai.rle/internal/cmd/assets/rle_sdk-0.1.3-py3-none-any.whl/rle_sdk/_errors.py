"""Error types raised by the RLE SDK."""

from __future__ import annotations

from typing import Optional


class RLEError(RuntimeError):
    """Raised when a call to a deployed RLE environment instance fails.

    Attributes:
        status: HTTP status code, when the failure came from an HTTP response.
        body: Raw response body (if any), useful for debugging server errors.
    """

    def __init__(self, message: str, *, status: Optional[int] = None, body: Optional[str] = None) -> None:
        super().__init__(message)
        self.status = status
        self.body = body
