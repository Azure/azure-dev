"""Shared helpers for leasing a hosted sandbox from the control plane by env id.

The SDK no longer points at a pre-deployed *instance* endpoint. Instead it leases
a short-lived **sandbox** for the life of the client from the control-plane
``EnvironmentSandboxController``::

    POST   rle/v1.0/projects/{project}/environments/{envId}/sandboxes        (lease)
    GET    rle/v1.0/projects/{project}/environments/{envId}/sandboxes/{id}   (poll ready)
    DELETE rle/v1.0/projects/{project}/environments/{envId}/sandboxes/{id}   (release)

The sync (:mod:`rle_sdk.client`) and async (:mod:`rle_sdk.aio`) clients implement
the transport (urllib vs. aiohttp) but share the URL/body building and the
``SandboxResponse`` parsing kept here.
"""

from __future__ import annotations

import os
from typing import Any, Dict, Mapping, Optional

# Deployed RLE control plane (eastus2 dev). Used as the default endpoint so recipes
# work out of the box; set ``RLE_CONTROL_PLANE`` to point at a different control
# plane (e.g. ``http://localhost:5000`` for local development).
_DEFAULT_CONTROL_PLANE_URL = (
    "https://rle-controlplane.orangeground-ba9696de.eastus2.azurecontainerapps.io"
)
DEFAULT_CONTROL_PLANE = os.environ.get("RLE_CONTROL_PLANE", _DEFAULT_CONTROL_PLANE_URL)
API_VERSION = "v1.0"

# Sandbox lifecycle states reported by the control plane (Core/Models/SandboxStatus.cs).
READY_STATUS = "Running"
FAILED_STATUS = "Failed"
TERMINAL_STATUSES = frozenset({READY_STATUS, FAILED_STATUS, "Stopped"})


def sandbox_collection_url(
    control_plane: str, project: str, env_id: str, api_version: str = API_VERSION
) -> str:
    """URL of the sandbox collection for an environment (POST to lease, GET to list)."""
    base = control_plane.rstrip("/")
    return f"{base}/rle/{api_version}/projects/{project}/environments/{env_id}/sandboxes"


def sandbox_url(
    control_plane: str,
    project: str,
    env_id: str,
    sandbox_id: str,
    api_version: str = API_VERSION,
) -> str:
    """URL of a single leased sandbox (GET to poll, DELETE to release)."""
    return f"{sandbox_collection_url(control_plane, project, env_id, api_version)}/{sandbox_id}"


def create_body(
    *,
    version: Optional[str] = None,
    cpu: Optional[float] = None,
    memory: Optional[str] = None,
    disk: Optional[str] = None,
    env_vars: Optional[Mapping[str, str]] = None,
) -> Dict[str, Any]:
    """Build the ``CreateSandboxRequest`` body, omitting unset fields."""
    body: Dict[str, Any] = {}
    if version is not None:
        body["version"] = version
    if cpu is not None:
        body["cpu"] = cpu
    if memory is not None:
        body["memory"] = memory
    if disk is not None:
        body["disk"] = disk
    if env_vars:
        body["envVars"] = dict(env_vars)
    return body


class SandboxLease:
    """Parsed ``SandboxResponse`` from the control plane."""

    __slots__ = ("id", "status", "url", "error", "raw")

    def __init__(self, payload: Mapping[str, Any]) -> None:
        self.id: str = str(payload.get("id", ""))
        self.status: str = str(payload.get("status", ""))
        self.url: Optional[str] = payload.get("url")
        self.error: Optional[str] = payload.get("error")
        self.raw: Dict[str, Any] = dict(payload)

    @property
    def is_ready(self) -> bool:
        return self.status == READY_STATUS

    @property
    def is_failed(self) -> bool:
        return self.status == FAILED_STATUS

    @property
    def is_terminal(self) -> bool:
        return self.status in TERMINAL_STATUSES
