"""Typed results returned by the RLE SDK.

These mirror the OpenEnv / Gymnasium wire format produced by the data plane::

    POST /reset, POST /step -> {"observation": {...}, "reward": <float|null>,
                                "terminated": <bool>, "truncated": <bool>,
                                "info": {...}}
    GET  /state             -> {"episode_id": <str|null>, "step_count": <int>, ...}

``terminated`` (a natural terminal state) and ``truncated`` (an external limit such as
``max_steps``) are kept distinct, as Gymnasium requires for correct bootstrapping; ``done`` is
derived (``terminated or truncated``) and retained for backward compatibility. Legacy payloads
that carry only ``done``/``metadata`` still bind. Each model keeps the full decoded payload in
``raw`` so callers can read fields the SDK does not model explicitly.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional


@dataclass
class StepResult:
    """Outcome of a :meth:`reset` or :meth:`step` call, in the OpenEnv / Gymnasium shape.

    ``terminated`` means the episode reached a natural terminal state (task solved/failed);
    ``truncated`` means an external limit ended it. ``done`` is derived and kept for callers
    written against the older single-flag shape.
    """

    observation: Dict[str, Any] = field(default_factory=dict)
    reward: Optional[float] = None
    terminated: bool = False
    truncated: bool = False
    info: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    raw: Dict[str, Any] = field(default_factory=dict)

    @property
    def done(self) -> bool:
        """Derived Gymnasium ``done`` flag: ``terminated or truncated`` (backward compatibility)."""
        return self.terminated or self.truncated

    @classmethod
    def from_wire(cls, data: Optional[Dict[str, Any]]) -> "StepResult":
        data = data or {}
        reward = data.get("reward")
        # Prefer the explicit Gymnasium flags; fall back to a legacy single ``done`` when neither
        # ``terminated`` nor ``truncated`` is present, so old data planes keep binding.
        has_split = "terminated" in data or "truncated" in data
        legacy_done = bool(data.get("done", False))
        terminated = bool(data.get("terminated", False if has_split else legacy_done))
        truncated = bool(data.get("truncated", False))
        info = data.get("info")
        metadata = data.get("metadata") or {}
        return cls(
            observation=data.get("observation") or {},
            reward=float(reward) if isinstance(reward, (int, float)) else None,
            terminated=terminated,
            truncated=truncated,
            info=info if isinstance(info, dict) else dict(metadata),
            metadata=metadata,
            raw=data,
        )


@dataclass
class EnvState:
    """Snapshot returned by :meth:`state`."""

    episode_id: Optional[str] = None
    step_count: int = 0
    raw: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_wire(cls, data: Optional[Dict[str, Any]]) -> "EnvState":
        data = data or {}
        try:
            step_count = int(data.get("step_count", 0))
        except (TypeError, ValueError):
            step_count = 0
        return cls(
            episode_id=data.get("episode_id"),
            step_count=step_count,
            raw=data,
        )
