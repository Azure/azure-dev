"""Asyncio client for a hosted RLE environment, leased by **env id** (aiohttp-backed).

This mirrors :class:`rle_sdk.RLEEnvironment` but is ``await``-able, which fits the
async agent loops used by the finetuning cookbook (``asyncio.gather`` over many
concurrent rollouts). ``aiohttp`` is imported lazily so importing ``rle_sdk`` does
not require it unless the async client is actually used.

The client takes an **environment id** (not a pre-deployed instance endpoint):
on first use it leases a fresh sandbox from the control plane, waits for it to
become ``Running``, then drives ``reset`` / ``step`` / ``state`` against the
sandbox's data plane. Closing the client (or leaving the ``async with`` block)
releases — deletes — the sandbox.

Install the async extra with::

    pip install rle-sdk[aio]
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from typing import Any, Dict, Mapping, Optional

from . import _lease
from ._errors import RLEError
from ._models import EnvState, StepResult
from .client import _is_warmup_error, coerce_action

logger = logging.getLogger(__name__)

# Substrings that mark a sandbox-create failure as a transient capacity shortage on the
# ADC fleet (surfaced by the control plane as HTTP 500/503). These are worth retrying
# because capacity is freed as other sandboxes are released.
_CAPACITY_ERROR_MARKERS = (
    "noclustersavailable",
    "no clusters",
    "sufficient capacity",
    "insufficient capacity",
)


def _is_capacity_error(err: RLEError) -> bool:
    """True if ``err`` looks like a transient ADC capacity shortage worth retrying."""
    if err.status is not None and err.status not in (500, 503):
        return False
    blob = f"{err} {err.body or ''}".lower()
    return any(marker in blob for marker in _CAPACITY_ERROR_MARKERS)


class AsyncRLEEnvironment:
    """Async, gym-style client for a hosted RLE environment leased by env id.

    Usage::

        async with AsyncRLEEnvironment(env_id="wordle-abc", project="demo") as env:
            await env.reset(seed=0)
            result = await env.step({"message": "hello"})
            state = await env.state()

    The first ``reset`` / ``step`` / ``state`` / ``health`` call leases a sandbox
    from the control plane (``control_plane``, default ``$RLE_CONTROL_PLANE`` or the
    deployed RLE control plane) and blocks until it is ``Running``; leaving the
    context (or calling :meth:`close`) deletes it.

    Pass an existing ``aiohttp.ClientSession`` via ``session=`` to share a
    connection pool across many environments; otherwise the client owns and
    closes its own session.
    """

    def __init__(
        self,
        env_id: str,
        *,
        project: Optional[str] = None,
        control_plane: Optional[str] = None,
        api_version: str = _lease.API_VERSION,
        timeout_s: float = 30.0,
        headers: Optional[Mapping[str, str]] = None,
        token: Optional[str] = None,
        session: Any = None,
        version: Optional[str] = None,
        cpu: Optional[float] = None,
        memory: Optional[str] = None,
        disk: Optional[str] = None,
        env_vars: Optional[Mapping[str, str]] = None,
        create_timeout_s: float = 300.0,
        poll_interval_s: float = 2.0,
        lease_retries: int = 10,
        lease_retry_backoff_s: float = 5.0,
        lease_retry_max_s: float = 30.0,
        reset_retries: int = 6,
        reset_retry_backoff_s: float = 2.0,
        reset_retry_max_s: float = 10.0,
        reset_replace_after: int = 2,
    ) -> None:
        if not env_id:
            raise ValueError("env_id is required")
        project = project or os.environ.get("RLE_PROJECT")
        if not project:
            raise ValueError("project is required (pass project= or set RLE_PROJECT)")
        self.env_id = env_id
        self.project = project
        self.control_plane = (control_plane or _lease.DEFAULT_CONTROL_PLANE).rstrip("/")
        self.api_version = api_version
        self.timeout_s = timeout_s
        self.create_timeout_s = create_timeout_s
        self.poll_interval_s = poll_interval_s
        self.lease_retries = lease_retries
        self.lease_retry_backoff_s = lease_retry_backoff_s
        self.lease_retry_max_s = lease_retry_max_s
        self.reset_retries = reset_retries
        self.reset_retry_backoff_s = reset_retry_backoff_s
        self.reset_retry_max_s = reset_retry_max_s
        self.reset_replace_after = reset_replace_after
        self._sandbox_opts = {
            "version": version,
            "cpu": cpu,
            "memory": memory,
            "disk": disk,
            "env_vars": env_vars,
        }
        self._headers: Dict[str, str] = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if headers:
            self._headers.update(headers)
        if token:
            self._headers["Authorization"] = f"Bearer {token}"
        self._session = session
        self._owns_session = session is None
        # Set once the sandbox is leased and Running.
        self.endpoint: Optional[str] = None
        self._sandbox_id: Optional[str] = None
        self._lease_lock = asyncio.Lock()

    async def __aenter__(self) -> "AsyncRLEEnvironment":
        await self._ensure_leased()
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.close()

    @property
    def sandbox_id(self) -> Optional[str]:
        """Id of the leased sandbox, or ``None`` before the first request."""
        return self._sandbox_id

    async def _get_session(self) -> Any:
        if self._session is None:
            import aiohttp

            self._session = aiohttp.ClientSession()
        return self._session

    async def close(self) -> None:
        """Release the leased sandbox and close the session if this client owns it."""
        try:
            await self._release_sandbox()
        finally:
            if self._owns_session and self._session is not None:
                await self._session.close()
                self._session = None

    # -- sandbox lease ------------------------------------------------------
    async def _ensure_leased(self) -> None:
        if self._sandbox_id is not None:
            return
        async with self._lease_lock:
            if self._sandbox_id is not None:
                return
            collection = _lease.sandbox_collection_url(
                self.control_plane, self.project, self.env_id, self.api_version
            )
            body = _lease.create_body(**self._sandbox_opts)
            created = _lease.SandboxLease(await self._create_sandbox(collection, body))
            self._sandbox_id = created.id
            lease = created
            loop = asyncio.get_event_loop()
            deadline = loop.time() + self.create_timeout_s
            sandbox_url = _lease.sandbox_url(
                self.control_plane, self.project, self.env_id, created.id, self.api_version
            )
            while not lease.is_ready:
                if lease.is_failed:
                    raise RLEError(
                        f"sandbox {created.id} failed to start: {lease.error or 'unknown error'}"
                    )
                if loop.time() > deadline:
                    raise RLEError(
                        f"sandbox {created.id} not ready after {self.create_timeout_s:.0f}s "
                        f"(last status: {lease.status or 'unknown'})"
                    )
                await asyncio.sleep(self.poll_interval_s)
                lease = _lease.SandboxLease(await self._control_request("GET", sandbox_url))
            if not lease.url:
                raise RLEError(f"sandbox {created.id} is Running but reported no data-plane url")
            self.endpoint = lease.url.rstrip("/")

    async def _create_sandbox(self, collection: str, body: Dict[str, Any]) -> Dict[str, Any]:
        """POST the sandbox-lease request, retrying transient ADC capacity shortages.

        A ``NoClustersAvailable`` (HTTP 500/503) response means the ADC fleet has no
        capacity *right now*; capacity frees up as other sandboxes are released, so we
        retry with exponential backoff (capped) up to ``lease_retries`` times.
        """
        attempt = 0
        while True:
            try:
                return await self._control_request("POST", collection, body)
            except RLEError as err:
                if attempt >= self.lease_retries or not _is_capacity_error(err):
                    raise
                delay = min(
                    self.lease_retry_backoff_s * (2 ** attempt),
                    self.lease_retry_max_s,
                )
                attempt += 1
                logger.warning(
                    "Sandbox lease for env %s hit a capacity shortage (%s); "
                    "retry %d/%d in %.0fs.",
                    self.env_id,
                    err,
                    attempt,
                    self.lease_retries,
                    delay,
                )
                await asyncio.sleep(delay)

    async def _release_sandbox(self) -> None:
        sandbox_id = self._sandbox_id
        if sandbox_id is None:
            return
        self._sandbox_id = None
        self.endpoint = None
        url = _lease.sandbox_url(
            self.control_plane, self.project, self.env_id, sandbox_id, self.api_version
        )
        try:
            await self._control_request("DELETE", url, expect_body=False)
        except RLEError:
            # Best-effort teardown; an already-gone sandbox is fine.
            pass

    # -- OpenEnv contract ---------------------------------------------------
    async def reset(
        self,
        seed: Optional[int] = None,
        episode_id: Optional[str] = None,
        **extra: Any,
    ) -> StepResult:
        body: Dict[str, Any] = {"seed": seed, "episode_id": episode_id, **extra}
        return StepResult.from_wire(await self._reset_with_warmup_retry(body))

    async def _reset_with_warmup_retry(self, body: Dict[str, Any]) -> Dict[str, Any]:
        """Drive ``/reset`` (the first data-plane call), retrying transient warm-up blips.

        A freshly-leased sandbox can be reported ``Running`` a moment before its
        in-sandbox HTTP server / adcproxy route is ready, so the first ``reset`` can
        transiently fail (e.g. HTTP 400 from the proxy). Most such blips clear within a
        couple of quick retries against the same endpoint. A sandbox that keeps failing
        past ``reset_replace_after`` attempts is treated as genuinely bad and is torn
        down and replaced with a fresh lease. Give up after ``reset_retries`` total
        attempts.
        """
        attempt = 0
        while True:
            try:
                return await self._request("POST", "/reset", body)
            except RLEError as err:
                if attempt >= self.reset_retries or not _is_warmup_error(err):
                    raise
                delay = min(
                    self.reset_retry_backoff_s * (2 ** attempt),
                    self.reset_retry_max_s,
                )
                attempt += 1
                replace = attempt % self.reset_replace_after == 0
                logger.warning(
                    "reset for sandbox %s (env %s) hit a transient warm-up error (%s); "
                    "retry %d/%d in %.0fs%s.",
                    self._sandbox_id,
                    self.env_id,
                    err,
                    attempt,
                    self.reset_retries,
                    delay,
                    " (replacing sandbox)" if replace else "",
                )
                await asyncio.sleep(delay)
                if replace:
                    # Same endpoint keeps failing -> the sandbox is likely bad. Tear it
                    # down and let the next request lease a fresh one.
                    await self._release_sandbox()

    async def step(self, action: Any = None, **action_kwargs: Any) -> StepResult:
        act = coerce_action(action, action_kwargs)
        return StepResult.from_wire(await self._request("POST", "/step", {"action": act}))

    async def state(self) -> EnvState:
        return EnvState.from_wire(await self._request("GET", "/state"))

    async def health(self) -> Dict[str, Any]:
        return await self._request("GET", "/health")

    async def metadata(self) -> Dict[str, Any]:
        return await self._request("GET", "/metadata")

    async def schema(self) -> Dict[str, Any]:
        return await self._request("GET", "/schema")

    # -- transport ----------------------------------------------------------
    async def _request(self, method: str, path: str, body: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        await self._ensure_leased()
        return await self._http(method, f"{self.endpoint}{path}", body)

    async def _control_request(
        self, method: str, url: str, body: Optional[Dict[str, Any]] = None, *, expect_body: bool = True
    ) -> Dict[str, Any]:
        return await self._http(method, url, body, send_body=method == "POST", expect_body=expect_body)

    async def _http(
        self,
        method: str,
        url: str,
        body: Optional[Dict[str, Any]] = None,
        *,
        send_body: Optional[bool] = None,
        expect_body: bool = True,
    ) -> Dict[str, Any]:
        import aiohttp

        session = await self._get_session()
        timeout = aiohttp.ClientTimeout(total=self.timeout_s)
        if send_body is None:
            send_body = method == "POST"
        payload = (body or {}) if send_body else None
        try:
            async with session.request(
                method, url, json=payload, headers=self._headers, timeout=timeout
            ) as resp:
                text = await resp.text()
                if resp.status >= 400:
                    raise RLEError(
                        f"{method} {url} failed: HTTP {resp.status}",
                        status=resp.status,
                        body=text,
                    )
        except asyncio.TimeoutError as e:
            # An aiohttp total-timeout raises asyncio.TimeoutError, which is NOT an
            # aiohttp.ClientError -- wrap it as a connection-level (status=None) RLEError
            # so callers (e.g. reset warm-up retry) treat it as a transient, retryable blip.
            raise RLEError(
                f"{method} {url} timed out after {self.timeout_s:.0f}s"
            ) from e
        except aiohttp.ClientError as e:
            raise RLEError(f"{method} {url} failed: {e}") from e

        if not text or not expect_body:
            return {}
        try:
            return json.loads(text)
        except json.JSONDecodeError as e:
            raise RLEError(f"{method} {url} returned non-JSON body", body=text) from e
