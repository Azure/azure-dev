"""Synchronous client for a hosted RLE environment, leased by env id."""

from __future__ import annotations

import json
import logging
import os
import socket
import time
import urllib.error
import urllib.request
from typing import Any, Dict, Mapping, Optional

from . import _lease
from ._errors import RLEError
from ._models import EnvState, StepResult

logger = logging.getLogger(__name__)

# HTTP statuses that a freshly-leased sandbox can briefly return on its first
# data-plane call: the control plane reports the sandbox ``Running`` (and hands back
# a data-plane url) a short moment before the in-sandbox HTTP server / adcproxy route
# is actually ready to serve, so the first ``reset`` can transiently fail. A
# connection-level error (``status is None``) during this window is treated the same way.
_WARMUP_RETRY_STATUSES = frozenset({400, 408, 421, 425, 429, 502, 503, 504})


def _is_warmup_error(err: RLEError) -> bool:
    """True if ``err`` looks like a transient post-lease readiness blip worth retrying."""
    return err.status is None or err.status in _WARMUP_RETRY_STATUSES


def coerce_action(action: Any, action_kwargs: Mapping[str, Any]) -> Dict[str, Any]:
    """Normalize a step action into a plain JSON-serializable dict.

    Accepts a mapping, a pydantic/dataclass-like object (``model_dump``/``to_dict``),
    or keyword fields. Exactly one form may be used per call.
    """
    if action is None:
        return dict(action_kwargs)
    if action_kwargs:
        raise TypeError("pass either a single action mapping or keyword fields, not both")
    if hasattr(action, "model_dump"):  # pydantic BaseModel
        return action.model_dump()
    if hasattr(action, "to_dict"):
        return action.to_dict()
    if isinstance(action, Mapping):
        return dict(action)
    raise TypeError(
        f"action must be a mapping or keyword fields, got {type(action).__name__}"
    )


class RLEEnvironment:
    """Gym-style client for a hosted RLE environment leased by **env id**.

    Point it at an environment id; on first use it leases a fresh sandbox from
    the control plane, waits for it to become ``Running``, and drives the
    environment seamlessly::

        with RLEEnvironment(env_id="wordle-abc", project="demo") as env:
            env.reset(seed=0)
            result = env.step({"message": "hello"})
            print(result.observation, result.reward, result.done)
            print(env.state().step_count)

    Leaving the ``with`` block (or calling :meth:`close`) deletes the sandbox.
    """

    def __init__(
        self,
        env_id: str,
        *,
        project: Optional[str] = None,
        control_plane: Optional[str] = None,
        api_version: str = _lease.API_VERSION,
        timeout_s: float = 30.0,
        headers: Optional[Mapping[str, str]] = None,
        token: Optional[str] = None,
        version: Optional[str] = None,
        cpu: Optional[float] = None,
        memory: Optional[str] = None,
        disk: Optional[str] = None,
        env_vars: Optional[Mapping[str, str]] = None,
        create_timeout_s: float = 300.0,
        poll_interval_s: float = 2.0,
        reset_retries: int = 6,
        reset_retry_backoff_s: float = 2.0,
        reset_retry_max_s: float = 10.0,
        reset_replace_after: int = 2,
    ) -> None:
        if not env_id:
            raise ValueError("env_id is required")
        project = project or os.environ.get("RLE_PROJECT")
        if not project:
            raise ValueError("project is required (pass project= or set RLE_PROJECT)")
        self.env_id = env_id
        self.project = project
        self.control_plane = (control_plane or _lease.DEFAULT_CONTROL_PLANE).rstrip("/")
        self.api_version = api_version
        self.timeout_s = timeout_s
        self.create_timeout_s = create_timeout_s
        self.poll_interval_s = poll_interval_s
        self.reset_retries = reset_retries
        self.reset_retry_backoff_s = reset_retry_backoff_s
        self.reset_retry_max_s = reset_retry_max_s
        self.reset_replace_after = reset_replace_after
        self._sandbox_opts = {
            "version": version,
            "cpu": cpu,
            "memory": memory,
            "disk": disk,
            "env_vars": env_vars,
        }
        self._headers: Dict[str, str] = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        if headers:
            self._headers.update(headers)
        if token:
            self._headers["Authorization"] = f"Bearer {token}"
        # Set once the sandbox is leased and Running.
        self.endpoint: Optional[str] = None
        self._sandbox_id: Optional[str] = None

    # -- context manager (symmetry with the async client) -------------------
    def __enter__(self) -> "RLEEnvironment":
        self._ensure_leased()
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    @property
    def sandbox_id(self) -> Optional[str]:
        """Id of the leased sandbox, or ``None`` before the first request."""
        return self._sandbox_id

    def close(self) -> None:
        """Release the leased sandbox (best-effort)."""
        self._release_sandbox()

    # -- sandbox lease ------------------------------------------------------
    def _ensure_leased(self) -> None:
        if self._sandbox_id is not None:
            return
        collection = _lease.sandbox_collection_url(
            self.control_plane, self.project, self.env_id, self.api_version
        )
        body = _lease.create_body(**self._sandbox_opts)
        created = _lease.SandboxLease(self._http("POST", collection, body))
        self._sandbox_id = created.id
        lease = created
        sandbox_url = _lease.sandbox_url(
            self.control_plane, self.project, self.env_id, created.id, self.api_version
        )
        deadline = time.monotonic() + self.create_timeout_s
        while not lease.is_ready:
            if lease.is_failed:
                raise RLEError(
                    f"sandbox {created.id} failed to start: {lease.error or 'unknown error'}"
                )
            if time.monotonic() > deadline:
                raise RLEError(
                    f"sandbox {created.id} not ready after {self.create_timeout_s:.0f}s "
                    f"(last status: {lease.status or 'unknown'})"
                )
            time.sleep(self.poll_interval_s)
            lease = _lease.SandboxLease(self._http("GET", sandbox_url))
        if not lease.url:
            raise RLEError(f"sandbox {created.id} is Running but reported no data-plane url")
        self.endpoint = lease.url.rstrip("/")

    def _release_sandbox(self) -> None:
        sandbox_id = self._sandbox_id
        if sandbox_id is None:
            return
        self._sandbox_id = None
        self.endpoint = None
        url = _lease.sandbox_url(
            self.control_plane, self.project, self.env_id, sandbox_id, self.api_version
        )
        try:
            self._http("DELETE", url, expect_body=False)
        except RLEError:
            # Best-effort teardown; an already-gone sandbox is fine.
            pass

    # -- OpenEnv contract ---------------------------------------------------
    def reset(
        self,
        seed: Optional[int] = None,
        episode_id: Optional[str] = None,
        **extra: Any,
    ) -> StepResult:
        """Start a new episode and return the initial observation."""
        body: Dict[str, Any] = {"seed": seed, "episode_id": episode_id, **extra}
        return StepResult.from_wire(self._reset_with_warmup_retry(body))

    def _reset_with_warmup_retry(self, body: Dict[str, Any]) -> Dict[str, Any]:
        """Drive ``/reset`` (the first data-plane call), retrying transient warm-up blips.

        A freshly-leased sandbox can be reported ``Running`` a moment before its
        in-sandbox HTTP server / adcproxy route is ready, so the first ``reset`` can
        transiently fail or time out. Retries use exponential backoff
        (``reset_retry_backoff_s`` doubling each attempt, capped at
        ``reset_retry_max_s``). A sandbox that keeps failing past
        ``reset_replace_after`` attempts is torn down and replaced with a fresh lease.
        Give up after ``reset_retries`` total attempts. Set ``reset_retries=0`` to
        disable retrying entirely.
        """
        attempt = 0
        while True:
            try:
                return self._request("POST", "/reset", body)
            except RLEError as err:
                if attempt >= self.reset_retries or not _is_warmup_error(err):
                    raise
                delay = min(
                    self.reset_retry_backoff_s * (2 ** attempt),
                    self.reset_retry_max_s,
                )
                attempt += 1
                replace = (
                    self.reset_replace_after > 0
                    and attempt % self.reset_replace_after == 0
                )
                logger.warning(
                    "reset for sandbox %s (env %s) hit a transient warm-up error (%s); "
                    "retry %d/%d in %.0fs%s.",
                    self._sandbox_id,
                    self.env_id,
                    err,
                    attempt,
                    self.reset_retries,
                    delay,
                    " (replacing sandbox)" if replace else "",
                )
                time.sleep(delay)
                if replace:
                    # Same endpoint keeps failing -> the sandbox is likely bad. Tear it
                    # down and let the next request lease a fresh one.
                    self._release_sandbox()

    def step(self, action: Any = None, **action_kwargs: Any) -> StepResult:
        """Apply an action and return the resulting observation/reward/done.

        ``action`` may be a mapping, a pydantic/dataclass-like object, or you may
        pass the action fields directly as keyword arguments::

            env.step({"message": "hi"})
            env.step(message="hi")
        """
        act = coerce_action(action, action_kwargs)
        return StepResult.from_wire(self._request("POST", "/step", {"action": act}))

    def state(self) -> EnvState:
        """Return the current environment state."""
        return EnvState.from_wire(self._request("GET", "/state"))

    def health(self) -> Dict[str, Any]:
        return self._request("GET", "/health")

    def metadata(self) -> Dict[str, Any]:
        return self._request("GET", "/metadata")

    def schema(self) -> Dict[str, Any]:
        return self._request("GET", "/schema")

    # -- transport ----------------------------------------------------------
    def _request(self, method: str, path: str, body: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        self._ensure_leased()
        return self._http(method, f"{self.endpoint}{path}", body)

    def _http(
        self,
        method: str,
        url: str,
        body: Optional[Dict[str, Any]] = None,
        *,
        expect_body: bool = True,
    ) -> Dict[str, Any]:
        data = json.dumps(body or {}).encode("utf-8") if method == "POST" else None
        req = urllib.request.Request(url, data=data, headers=self._headers, method=method)
        try:
            with urllib.request.urlopen(req, timeout=self.timeout_s) as resp:
                raw = resp.read().decode("utf-8")
        except urllib.error.HTTPError as e:
            detail = ""
            try:
                detail = e.read().decode("utf-8", "replace")
            except Exception:  # pragma: no cover - best-effort body read
                pass
            raise RLEError(
                f"{method} {url} failed: HTTP {e.code}", status=e.code, body=detail
            ) from e
        except (TimeoutError, socket.timeout) as e:
            # A socket read-timeout raises bare TimeoutError/socket.timeout (not a
            # urllib.error.URLError) -- wrap it as a connection-level (status=None) RLEError
            # so callers (e.g. reset warm-up retry) treat it as a transient, retryable blip.
            raise RLEError(f"{method} {url} timed out after {self.timeout_s:.0f}s") from e
        except urllib.error.URLError as e:
            raise RLEError(f"{method} {url} failed: {e.reason}") from e

        if not raw or not expect_body:
            return {}
        try:
            return json.loads(raw)
        except json.JSONDecodeError as e:
            raise RLEError(f"{method} {url} returned non-JSON body", body=raw) from e
